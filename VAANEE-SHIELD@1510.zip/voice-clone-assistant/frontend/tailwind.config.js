/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        base: {
          950: '#070B14',
          900: '#0B1120',
          850: '#0E1526',
          800: '#121A2E',
          700: '#1A2438',
          600: '#26314A',
        },
        brand: {
          400: '#8B7CF6',
          500: '#7C5CFC',
          600: '#6941E8',
        },
        risk: {
          low: '#34D399',
          medium: '#FBBF24',
          high: '#FB923C',
          critical: '#F87171',
        },
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(124,92,252,0.15), 0 8px 30px -10px rgba(124,92,252,0.25)',
      },
    },
  },
  plugins: [],
}
